import React from 'react'

function Listings() {
  return (
    <div className='container text-center p-[120px]'>
        <i>An Internal Error Has Occured!</i>
        <p>Please Contact Hosting Provider</p>
    </div>
  )
}

export default Listings