import { useState } from "react";
import { motion } from "framer-motion";
const MenuToggle = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      
      <nav className="bg-blue-600 p-4 shadow-lg ">
            <div className="container mx-auto flex justify-between items-center">
                <h1 className="text-white text-xl font-bold">Brand</h1>
                
                {/* Toggle Button for Tablets and Smaller Screens */}
                <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-white text-2xl focus:outline-none">
                    {isOpen ? "✖" : "☰"}
                </button>
                
                {/* Navigation Links */}
                <ul className="hidden md:flex space-x-6 text-white font-semibold">
                    <li><a href="#" className="hover:text-gray-300">Home</a></li>
                    <li><a href="#" className="hover:text-gray-300">Blogs</a></li>
                    <li><a href="#" className="hover:text-gray-300">About Us</a></li>
                </ul>
            </div>

            {/* Animated Dropdown Menu for Small Screens */}
            <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: isOpen ? 1 : 0, height: isOpen ? "auto" : 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className={`md:hidden overflow-hidden bg-blue-700 text-white text-center py-4 space-y-4`}
            >
                <a href="#" className="block hover:bg-blue-500 py-2">Home</a>
                <a href="#" className="block hover:bg-blue-500 py-2">Blogs</a>
                <a href="#" className="block hover:bg-blue-500 py-2">About Us</a>
            </motion.div>
        </nav>

    </div>
  );
};

export default MenuToggle;
