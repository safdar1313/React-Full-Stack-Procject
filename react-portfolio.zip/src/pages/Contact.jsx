import React, { useState } from "react";
import Breadcrumb from "../dynamic-components/Breadcrumb";

const Contact = () => {
  const [IsOpen, setIsOpen] = useState(false)

  return (
    <div className="contact w-full">
    <Breadcrumb/>
    <div className="container p-6 px-6">
      <button onClick={()=>{setIsOpen(!IsOpen)}}>Toggle Menu</button>      
      <ul className={`${IsOpen ? 'block': 'hidden'}`}>
        <li>Name</li>
        <li>List</li>
        <li>Anchors</li>
        <li>Programings</li>
      </ul>
    </div>
    </div>
  );
};

export default Contact; 